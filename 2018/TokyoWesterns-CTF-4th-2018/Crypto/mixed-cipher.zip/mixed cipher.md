# mixed cipher

### Problem

I heard bulldozer is on this channel, be careful!
`nc crypto.chal.ctf.westerns.tokyo 5643`
[server.py](https://static.score.ctf.westerns.tokyo/attachments/20/server-0b4900a4522dfa4f15489f312d352ebbdd52ff96d724362523c84bc6e3501063.py) 