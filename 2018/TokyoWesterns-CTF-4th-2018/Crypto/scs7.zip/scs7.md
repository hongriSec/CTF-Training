# scs7

### Problem

```
nc crypto.chal.ctf.westerns.tokyo 14791
```

Note: You can encrypt up to 100 messages "per once connection".