# pysandbox

### Problem

let's break [sandbox](https://static.score.ctf.westerns.tokyo/attachments/22/sandbox-e3cc8217b5f7502deb32f9096375e3e5d043031260f39cb8ab2513e14a7cb392.py).
start from `nc pwn1.chal.ctf.westerns.tokyo 30001` 