# vimshell

### Problem

Can you escape from [jail](http://vimshell.chal.ctf.westerns.tokyo/)?