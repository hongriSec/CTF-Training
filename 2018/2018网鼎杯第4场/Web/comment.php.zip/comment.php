<?php
include "mysql.php";
session_start();
if($_SESSION['login'] != 'yes'){
    header("Location: ./login.php");
    die();
}
if(isset($_GET['do'])){
    switch ($_GET['do'])
    {
        case 'write':
            $category = addslashes($_POST['category']);
            $title = addslashes($_POST['title']);
            $content = addslashes($_POST['content']);
            $sql = "insert into board
                    set category = '$category',
                        title = '$title',
                        content = '$content'";
            $result = mysql_query($sql);
            header("Location: ./index.php");
            break;
        case 'comment':
            $bo_id = addslashes($_POST['bo_id']);
            $sql = "select category from board where id='$bo_id'";
            $result = mysql_query($sql);
            $num = mysql_num_rows($result);
            if($num>0){
            $category = mysql_fetch_array($result)['category'];
            $content = addslashes($_POST['content']);
            $sql = "insert into comment
                    set category = '$category',
                        content = '$content',
                        bo_id = '$bo_id'";
            $result = mysql_query($sql);
            }
            header("Location: ./comment.php?id=$bo_id");
            break;
        default:
            header("Location: ./index.php");
    }
}
else{
    header("Location: ./index.php");
}
?>