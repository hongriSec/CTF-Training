<?php
 function authcode($string, $operation = 'DECODE', $key , $expiry = 0) {
	$ckey_length = 4; 

	$key = md5($key);
	$keya = md5(substr($key, 0, 16));
	$keyb = md5(substr($key, 16, 16));
	$keyc = $ckey_length ? ($operation == 'DECODE' ? substr($string, 0, $ckey_length): substr(md5(microtime()), -$ckey_length)) : '';

	$cryptkey = $keya.md5($keya.$keyc);
	$key_length = strlen($cryptkey);

	$string = $operation == 'DECODE' ? base64_decode(substr($string, $ckey_length)) : sprintf('%010d', $expiry ? $expiry + time() : 0).substr(md5($string.$keyb), 0, 16).$string;
	$string_length = strlen($string);

	$result = '';
	$box = range(0, 255);

	$rndkey = array();
	for($i = 0; $i <= 255; $i++) {
		$rndkey[$i] = ord($cryptkey[$i % $key_length]);
	}

	for($j = $i = 0; $i < 256; $i++) {
		$j = ($j + $box[$i] + $rndkey[$i]) % 256;
		$tmp = $box[$i];
		$box[$i] = $box[$j];
		$box[$j] = $tmp;
	}

	for($a = $j = $i = 0; $i < $string_length; $i++) {
		$a = ($a + 1) % 256;
		$j = ($j + $box[$a]) % 256;
		$tmp = $box[$a];
		$box[$a] = $box[$j];
		$box[$j] = $tmp;
		$result .= chr(ord($string[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
	}

	if($operation == 'DECODE') {
		if((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0) && substr($result, 10, 16) == substr(md5(substr($result, 26).$keyb), 0, 16)) {
			return substr($result, 26);
		} else {
			return '';
		}
	} else {
		return $keyc.str_replace('=', '', base64_encode($result));
	}

}
$key=trim(file_get_contents('authcode.php'));
$key=str_replace("<?php\n/*",'',$key);
$key=str_replace('*/?>','',$key);

$dir = scandir('./');
foreach ($dir as $k => $v) {
	if(preg_match('/^[0-9A-Za-z]{8}\.php$/',$v) && $v!='authcode.php' && $v!='download.php'){
		$rand_file_str = authcode('filename='.$v, 'ENCODE', $key);
	}
}
$ctf = authcode('filename=static/ctf.txt', 'ENCODE', $key);
$defcon = authcode('filename=static/defcon.txt', 'ENCODE', $key);
$flag = authcode('filename=static/flag.jpg', 'ENCODE', $key);
?>
<!DOCTYPE html>
<html lang="zh-CN">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="">

		<title>Navbar Template for Bootstrap</title>

		<link href="static/css/bootstrap.min.css" rel="stylesheet">

	</head>

	<body>

		<div class="container">
			<br>
			<!-- Static navbar -->
			<nav class="navbar navbar-default">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="#">Project name</a>
					</div>
					<div id="navbar" class="navbar-collapse collapse">
						<ul class="nav navbar-nav">
							<li class="active"><a href="#">DownLoad</a></li>
							<li><a href="install.html">install.php</a></li>
							<li><a href="download.html">download.php</a></li>
						</ul>

					</div><!--/.nav-collapse -->
				</div><!--/.container-fluid -->
			</nav>

			<!-- Main component for a primary marketing message or call to action -->
			<div class="jumbotron container">
				<h1 class="text-center">DownLoad</h1>
				<p class="text-center">Flag is here, try to get it.</p>
				<br>
				<div class="container">
					<a class="btn btn-lg btn-success col-md-offset-2" href="download.php?download=<?php echo urlencode($ctf)?>" >CTF Introduction</a> 
					<a class="btn btn-lg btn-success col-md-offset-1" href="download.php?download=<?php echo urlencode($defcon)?>" >DEFCON Introduction</a>
					<a class="btn btn-lg btn-success col-md-offset-1" href="download.php?download=<?php echo urlencode($flag)?>" >FLAG</a> 
					<!-- <a class="btn btn-lg btn-success" href="download.php?download=<?php echo urlencode($rand_file_str)?>" ></a>  -->
				</div>


			</div>

		</div> <!-- /container -->

		<script src="static/js/jquery.min.js"></script>
		<script>window.jQuery || document.write('<script src="static/js/jquery.min.js"><\/script>')</script>
		<script src="static/js/bootstrap.min.js"></script>

	</body>
</html>