<?php
/* VSERION = 7.0.30 */
if(file_exists('install.lock')){
	exit();
}

function gen_rand($length){
	$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	$randstr = '';
	for ( $i = 0; $i < $length; $i++ ) {
		$randstr .= $chars[ mt_rand(0, strlen($chars) - 1) ];
	}
	return $randstr;
}

function wfile($filename, $content=""){
	$fp  = @fopen($filename, 'w');
	@fwrite($fp,$content);
	@fclose($fp);
}

wfile('install.lock','');
wfile(gen_rand(8).'.php', "<?php //flag{This is fake flag, but it looks useful}");
wfile('authcode.php',"<?php\n/*".gen_rand(32).'*/?>');


