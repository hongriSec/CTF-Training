#!/usr/bin/env python2

from hashlib import md5
from flag import FLAG, K1, K2
import sys 

assert len(K1) < 64
assert len(K2) == 5


def xor(a, b):
    return ''.join(chr(ord(i) ^ ord(j)) for i, j in zip(a, b))


def process(msg):
    msg = list(msg)
    msg[0] = chr(ord(msg[-1]) ^ ord(msg[0]))
    return ''.join(msg)


def type1(msg):
    data = K1 + msg + K2
    hash = ''
    hash += md5(data[:64]).digest()
    hash += md5(data[64:]).digest()
    return md5(hash).digest()


def type2_1(msg):
    return md5(process(msg[-5:]) + xor(msg[-10: -5], K2)).digest()


def type2_2(msg):
    return md5(msg[-5:] + xor(msg[-10:-5], K2)).digest()


def type3(msg):
    temp = int(msg.encode('hex'), 16)
    _K2 = int(K2.encode('hex'), 16)
    return temp ^ _K2


def The_Game():
    introduction = """
    Hey man, wanna play a Super perm game?

    .--.     .--------------.
    | _|     |              |
    | O O   <  PERM GAME :) |
    |  |  |  |              |
    || | /   `--------------'
    |`-'|
    `---'

    IYKWIM	:heart: <==3
    """
    print introduction
    
    print " m1 = ",
    sys.stdout.flush()
    m1 = sys.stdin.readline().strip()
    
    print 'm2 = ',
    sys.stdout.flush()
    m2 = sys.stdin.readline().strip()
    print "m3 = ",
    sys.stdout.flush()
    m3 = sys.stdin.readline().strip()

    #print "\nYour input is:\n"
    #print "- m1 = {!r}".format(m1)
    #print "- m2 = {!r}".format(m2)
    #print "- m3 = {!r}".format(m3)

    try:
        assert len(m1) > 20
        assert len(m2) > 20
        assert m1 != m2

        h1_1 = type1(m1)
        h1_2 = type2_1(m1)

        h2_1 = type1(m2)
        h2_2 = type2_2(m2)

        h3 = type3(m3)

        temp1 = xor(h1_1, h2_1)
        temp1 = int(temp1.encode('hex'), 16)
        temp2 = xor(h1_2, h2_2)
        temp2 = int(temp2.encode('hex'), 16)
        temp3 = h3

        # print h1_1.encode('hex'), h2_1.encode('hex')

        # print temp1
        # print temp2
        # print temp3

        if temp1 == 0 and temp2 == 0 and temp3 == 0:
            print "\nCongratz homies.\n"
            print FLAG
        else:
            print "\nWrong. {}".format(h1_2.encode('hex'))
    except:
        print "Take your time to think of the inputs."
        pass


if __name__ == "__main__":
    try:
        The_Game()
    except:
        pass
        import sys
        sys.exit()

