<?php 
$_SESSION = NULL;
header('location: /login.php')
?>
