FLAG = "LCTF{m@y_7h3_f0rc3_6e_w1th_y0u_Dvzq2}"
seed = "lctf2018HDnxfM4y"
