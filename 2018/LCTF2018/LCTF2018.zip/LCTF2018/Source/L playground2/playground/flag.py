FLAG = ""
seed = ""
