<?php
$flag = "whaleCTF{7234hjbv82hjsd0a23jksa}";
echo $flag;

